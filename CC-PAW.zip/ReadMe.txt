How to install this resource pack:

1. Open Minecraft
2. Click "OPTIONS"
3. Click "RESOURCE PACKS"
4. Click "OPEN RESOURCE PACK FOLDER"
5. Drag & drop "CC-PAW" into that folder
